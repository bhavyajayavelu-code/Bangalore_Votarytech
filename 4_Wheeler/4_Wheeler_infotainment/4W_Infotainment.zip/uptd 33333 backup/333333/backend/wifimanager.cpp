#include "wifimanager.h"
#include <QDebug>
#include <QRegularExpression>
#include <QRegularExpressionMatchIterator>

WifiManager::WifiManager(QObject *parent) : QObject(parent)
    , m_isConnected(false)
    , m_isScanning(false)
{
    m_scanProcess = new QProcess(this);
    m_connectProcess = new QProcess(this);
    m_scanTimer = new QTimer(this);

    m_scanTimer->setInterval(30000); // Auto-scan every 30 seconds
    connect(m_scanTimer, &QTimer::timeout, this, &WifiManager::scanNetworks);
    m_scanTimer->start();

    // Initial scan
    QTimer::singleShot(1000, this, &WifiManager::scanNetworks);
}

QStringList WifiManager::networks() const {
    return m_networks;
}

QString WifiManager::currentSSID() const {
    return m_currentSSID;
}

bool WifiManager::isConnected() const {
    return m_isConnected;
}

bool WifiManager::isScanning() const {
    return m_isScanning;
}

void WifiManager::scanNetworks() {
    if (m_isScanning) return;

    m_isScanning = true;
    emit scanningChanged();

    #ifdef Q_OS_LINUX
    m_scanProcess->start("nmcli", QStringList() << "-t" << "-f" << "SSID,SIGNAL,SECURITY" << "device" << "wifi" << "list");
    #elif defined(Q_OS_ANDROID)
    // Android specific scanning (requires permissions)
    m_scanProcess->start("cmd", QStringList() << "wifi" << "scan");
    #elif defined(Q_OS_WIN)
    m_scanProcess->start("netsh", QStringList() << "wlan" << "show" << "networks");
    #endif

    connect(m_scanProcess, QOverload<int>::of(&QProcess::finished),
            this, &WifiManager::onScanFinished);
}

void WifiManager::onScanFinished(int exitCode) {
    m_isScanning = false;
    emit scanningChanged();

    if (exitCode == 0) {
        QString output = QString::fromUtf8(m_scanProcess->readAllStandardOutput());
        parseScanResults(output);
        emit scanCompleted();
    }

    m_scanProcess->disconnect(this);
}

void WifiManager::parseScanResults(const QString &output) {
    QStringList newNetworks;

    #ifdef Q_OS_LINUX
    // Parse nmcli output format: SSID:SIGNAL:SECURITY
    QStringList lines = output.split('\n', QString::SkipEmptyParts);
    for (const QString &line : lines) {
        QStringList parts = line.split(':');
        if (parts.size() >= 3) {
            QString ssid = parts[0];
            QString strength = parts[1];
            QString security = parts[2];

            if (!ssid.isEmpty() && ssid != "--") {
                // Format: "NetworkName (Signal: 75%, WPA2)"
                QString display = QString("%1 (Signal: %2%, %3)")
                                    .arg(ssid)
                                    .arg(strength)
                                    .arg(security.isEmpty() ? "Open" : security);
                newNetworks << display;
            }
        }
    }
    #endif

    m_networks = newNetworks;
    emit networksChanged();
}

void WifiManager::connectToNetwork(const QString &ssid, const QString &password) {
    qDebug() << "Connecting to:" << ssid;

    // Extract pure SSID from display string
    QString cleanSSID = ssid;
    if (cleanSSID.contains('(')) {
        cleanSSID = cleanSSID.left(cleanSSID.indexOf('(')).trimmed();
    }

    #ifdef Q_OS_LINUX
    QStringList args;
    if (password.isEmpty()) {
        args << "device" << "wifi" << "connect" << cleanSSID;
    } else {
        args << "device" << "wifi" << "connect" << cleanSSID << "password" << password;
    }

    m_connectProcess->start("nmcli", args);
    #endif

    connect(m_connectProcess, QOverload<int>::of(&QProcess::finished),
            this, &WifiManager::onConnectFinished);
}

void WifiManager::onConnectFinished(int exitCode) {
    if (exitCode == 0) {
        m_isConnected = true;

        // Get connected SSID
        #ifdef Q_OS_LINUX
        QProcess p;
        p.start("nmcli", QStringList() << "-t" << "-f" << "GENERAL.CONNECTION" << "device" << "show" << "wlan0");
        p.waitForFinished();
        QString output = QString::fromUtf8(p.readAllStandardOutput());
        m_currentSSID = output.split(':').value(0).trimmed();
        #endif

        emit connectionChanged();
        emit connectionSuccess();
        qDebug() << "Connected to:" << m_currentSSID;
    } else {
        QString error = QString::fromUtf8(m_connectProcess->readAllStandardError());
        emit connectionFailed(error);
        qDebug() << "Connection failed:" << error;
    }

    m_connectProcess->disconnect(this);
}

void WifiManager::disconnectFromNetwork() {
    #ifdef Q_OS_LINUX
    QProcess::execute("nmcli", QStringList() << "device" << "disconnect" << "wlan0");
    #endif

    m_isConnected = false;
    m_currentSSID.clear();
    emit connectionChanged();
}

void WifiManager::forgetNetwork(const QString &ssid) {
    QString cleanSSID = ssid;
    if (cleanSSID.contains('(')) {
        cleanSSID = cleanSSID.left(cleanSSID.indexOf('(')).trimmed();
    }

    #ifdef Q_OS_LINUX
    QProcess::execute("nmcli", QStringList() << "connection" << "delete" << cleanSSID);
    #endif

    // Rescan networks
    scanNetworks();
}

QString WifiManager::getNetworkStrength(const QString &ssid) {
    Q_UNUSED(ssid)  // Tell compiler we're intentionally not using it
    // This is a simplified version
    // In real implementation, you'd parse signal strength
    return "75%"; // Placeholder
}
