#pragma once
#include <QObject>
#include <QStringList>

class BluetoothManager : public QObject {
    Q_OBJECT
    Q_PROPERTY(QStringList devices READ devices NOTIFY devicesChanged)
public:
    explicit BluetoothManager(QObject *parent = nullptr);

    Q_INVOKABLE void scanDevices();
    Q_INVOKABLE void connectDevice(const QString &mac);

    QStringList devices() const { return m_devices; }

signals:
    void devicesChanged();

private:
    QStringList m_devices;
};
