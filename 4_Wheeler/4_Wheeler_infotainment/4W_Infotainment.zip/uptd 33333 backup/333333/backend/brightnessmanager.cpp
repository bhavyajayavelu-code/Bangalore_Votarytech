#include "brightnessmanager.h"
#include <QFile>

BrightnessManager::BrightnessManager(QObject*) {
    QFile f("/sys/class/backlight/intel_backlight/brightness");
    if (f.open(QIODevice::ReadOnly))
        m_brightness = f.readAll().toInt();
}

int BrightnessManager::brightness() const {
    return m_brightness;
}

void BrightnessManager::setBrightness(int value) {
    QFile f("/sys/class/backlight/intel_backlight/brightness");
    if (f.open(QIODevice::WriteOnly)) {
        f.write(QByteArray::number(value));
        m_brightness = value;
        emit brightnessChanged();
    }
}
