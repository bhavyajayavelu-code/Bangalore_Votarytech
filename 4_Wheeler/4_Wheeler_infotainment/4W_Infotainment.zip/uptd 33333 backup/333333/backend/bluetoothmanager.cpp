#include "bluetoothmanager.h"
#include <QProcess>
#include <QDebug>

BluetoothManager::BluetoothManager(QObject *parent) : QObject(parent) {
    // Initial fake devices
    m_devices = QStringList() << "AA:BB:CC:DD:EE:01 - Phone"
                              << "AA:BB:CC:DD:EE:02 - Speaker"
                              << "AA:BB:CC:DD:EE:03 - Headset";
}

void BluetoothManager::scanDevices() {
    QProcess process;
    process.start("bash", QStringList() << "-c" << "bluetoothctl devices");
    process.waitForFinished(3000); // wait max 3 seconds

    QString output = process.readAllStandardOutput();
    QStringList list = output.split("\n", QString::SkipEmptyParts);

    // If no real devices, use fake list
    if (list.isEmpty()) {
        m_devices = QStringList() << "AA:BB:CC:DD:EE:01 - Phone"
                                  << "AA:BB:CC:DD:EE:02 - Speaker"
                                  << "AA:BB:CC:DD:EE:03 - Headset";
    } else {
        m_devices = list;
    }

    emit devicesChanged();
}

void BluetoothManager::connectDevice(const QString &mac) {
}
