#pragma once
#include <QObject>

class BrightnessManager : public QObject {
    Q_OBJECT
    Q_PROPERTY(int brightness READ brightness NOTIFY brightnessChanged)
public:
    explicit BrightnessManager(QObject *parent=nullptr);
    int brightness() const;
    Q_INVOKABLE void setBrightness(int value);

signals:
    void brightnessChanged();

private:
    int m_brightness;
};
