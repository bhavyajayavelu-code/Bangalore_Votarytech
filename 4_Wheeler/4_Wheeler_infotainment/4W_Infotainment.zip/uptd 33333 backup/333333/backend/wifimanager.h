#ifndef WIFIMANAGER_H
#define WIFIMANAGER_H

#include <QObject>
#include <QStringList>
#include <QProcess>
#include <QTimer>

class WifiManager : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QStringList networks READ networks NOTIFY networksChanged)
    Q_PROPERTY(QString currentSSID READ currentSSID NOTIFY connectionChanged)
    Q_PROPERTY(bool isConnected READ isConnected NOTIFY connectionChanged)
    Q_PROPERTY(bool isScanning READ isScanning NOTIFY scanningChanged)

public:
    explicit WifiManager(QObject *parent = nullptr);

    QStringList networks() const;
    QString currentSSID() const;
    bool isConnected() const;
    bool isScanning() const;

    Q_INVOKABLE void scanNetworks();
    Q_INVOKABLE void connectToNetwork(const QString &ssid, const QString &password);
    Q_INVOKABLE void disconnectFromNetwork();
    Q_INVOKABLE void forgetNetwork(const QString &ssid);
    Q_INVOKABLE QString getNetworkStrength(const QString &ssid);

signals:
    void networksChanged();
    void connectionChanged();
    void scanningChanged();
    void scanCompleted();
    void connectionSuccess();
    void connectionFailed(const QString &error);
    void passwordRequired(const QString &ssid);

private slots:
    void onScanFinished(int exitCode);
    void onConnectFinished(int exitCode);

private:
    QStringList m_networks;
    QString m_currentSSID;
    bool m_isConnected;
    bool m_isScanning;
    QProcess *m_scanProcess;
    QProcess *m_connectProcess;
    QTimer *m_scanTimer;

    void parseScanResults(const QString &output);
    QString executeCommand(const QString &cmd);
};

#endif // WIFIMANAGER_H
