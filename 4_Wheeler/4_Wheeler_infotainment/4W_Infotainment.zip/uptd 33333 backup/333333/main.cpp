#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QCoreApplication>
#include <QUrl>
//#include <QtWebEngine>  // ADD THIS
#include <QDebug>
#include <QtGlobal>
#include <QSurfaceFormat>
#include <QtQml>

#include "backend/wifimanager.h"
#include "backend/bluetoothmanager.h"
#include "backend/brightnessmanager.h"

// Platform-specific web initialization
#ifdef Q_OS_ANDROID
#include <QtWebView/QtWebView>
#else
#include <QtWebEngine/QtWebEngine>
#endif

int main(int argc, char *argv[])
{
    // ---------- Platform Setup (BEFORE QGuiApplication) ----------
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

#ifdef Q_OS_ANDROID
    // Android: Use OpenGL ES + WebView
    QCoreApplication::setAttribute(Qt::AA_UseOpenGLES);
    QtWebView::initialize();  // CRITICAL: Must be before QGuiApplication
#else
    // Desktop: Share GL contexts + WebEngine
    QCoreApplication::setAttribute(Qt::AA_ShareOpenGLContexts);
    //QtWebEngine::initialize();
#endif

    // ---------- Application ----------
    QGuiApplication app(argc, argv);

    // ---------- Register Backend Classes for QML ----------
    qmlRegisterType<BluetoothManager>("Car.Backend", 1, 0, "BluetoothManager");
    qmlRegisterType<WifiManager>("Car.Backend", 1, 0, "WifiManager");
    qmlRegisterType<BrightnessManager>("Car.Backend", 1, 0, "BrightnessManager");

    // ---------- QML Engine ----------
    QQmlApplicationEngine engine;
    const QUrl url(QStringLiteral("qrc:/main.qml"));

    // Connection for QML loading errors
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
                         if (!obj && url == objUrl) {
                             qCritical() << "❌ QML failed to load";
                             QCoreApplication::exit(-1);
                         } else if (obj) {
                             qDebug() << "✅ QML loaded successfully";
                         }
                     }, Qt::QueuedConnection);

    engine.load(url);

    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}
