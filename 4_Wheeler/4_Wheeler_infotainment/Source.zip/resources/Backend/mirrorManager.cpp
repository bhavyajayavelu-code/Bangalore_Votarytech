#include "mirrorManager.h"
#include <QDebug>
#include <QPainter>
#include <QProcess>
#include <QTimer>
#ifdef Q_OS_ANDROID
#include <QAndroidJniObject>
#include <QtAndroid>
#include <jni.h>
#include <QAndroidJniEnvironment>
#endif
// #include <QAndroidJniObject>
// #include <QtAndroid>
extern "C"
JNIEXPORT void JNICALL
Java_com_VTech_1POC_mirror_MirrorActivity_testFromJava(JNIEnv *env,
                                                       jobject thiz)
{
    qDebug() << "JNI call successful!";
}
extern "C"
JNIEXPORT void JNICALL
Java_com_VTech_1POC_mirror_MirrorActivity_requestCaptureFromQt(
    JNIEnv *env,
    jobject thiz)
{
    qDebug() << "JNI: requestCaptureFromQt received";
}
extern "C"
    JNIEXPORT jint JNICALL
    Java_com_VTech_1POC_mirror_MirrorActivity_nativePing(
        JNIEnv *, jobject) {
    return 42;
}
extern "C"
    JNIEXPORT void JNICALL
    Java_com_VTech_1POC_mirror_MirrorActivity_nativeOnFrameAvailable(
        JNIEnv *env, jobject,
        jobject buffer, jint w, jint h)
{
    uint8_t *data =
        static_cast<uint8_t *>(env->GetDirectBufferAddress(buffer));

    MirrorManager::instance()->updateFrame(data, w, h);
}

void MirrorManager::updateFrame(uint8_t *data, int w, int h)
{
    QImage img(data, w, h, QImage::Format_RGBA8888);
    m_frame = img.copy();  // important
    m_mirroring = true;
    emit frameUpdated();
}
extern void setMirrorManager(MirrorManager*);
MirrorManager::MirrorManager(QObject *parent) : QObject(parent) {
    // connect(&m_mockTimer, &QTimer::timeout, this, [this]() {
        connect(&m_mockTimer, &QTimer::timeout,
                this, &MirrorManager::generateFrame);
        m_frame = QImage(800, 480, QImage::Format_RGB32);
        m_frame.fill(Qt::black);

        QPainter p(&m_frame);
        p.setPen(Qt::green);
        p.setFont(QFont("Arial", 24));
        p.drawText(m_frame.rect(), Qt::AlignCenter,
                   "Mock Android Frame\nUSB Mirroring");
        p.end();

        // emit frameChanged();
        setMirrorManager(this);
        emit frameUpdated();
    // });
}

void MirrorManager::startCapture()
{
    qDebug() << "startCapture call successful!";
    QAndroidJniObject activity = QtAndroid::androidActivity();
    activity.callMethod<void>("startCaptureFromQt");
}
void MirrorManager::startMirroring()
{
    m_mirroring = true;
    emit mirroringChanged();
#ifdef Q_OS_ANDROID
    QAndroidJniObject activity =
        QAndroidJniObject::callStaticObjectMethod(
            "org/qtproject/qt5/android/QtNative",
            "activity",
            "()Landroid/app/Activity;"
            );

    if (!activity.isValid()) {
        qDebug() << "Activity invalid";
        return;
    }

    // Android logic here
#else
    // Desktop fallback (mock)
    startMockTimer();
#endif
}
void MirrorManager::stopMirroring()
{
    if (!m_mirroring)
        return;

    // m_timer.stop();
    m_mirroring = false;
    emit mirroringChanged();
    m_mockTimer.stop();
}
void MirrorManager::generateMockFrame()
{
    QImage img(720, 480, QImage::Format_RGB32);
    img.fill(QColor::fromHsv(qrand() % 360, 255, 255));

    emit frameReady(img);
}
void MirrorManager::generateFrame()
{
    // if (!m_mirroring)
    //     return;

    // static int counter = 0;

    QImage frame(800, 480, QImage::Format_RGB32);
    frame.fill(Qt::black);

    QPainter p(&frame);
    p.setPen(Qt::green);
    p.setFont(QFont("Sans", 24));
    // p.drawText(frame.rect(), Qt::AlignCenter,
    //            QString("Mock Frame %1").arg(counter++));
    p.drawText(frame.rect(), Qt::AlignCenter, "Mock Mirroring");
    p.end();
    qDebug() << "Frame updated, valid =" << !frame.isNull();
    emit frameReady(frame);
    emit frameUpdated();
}
void MirrorManager::startMockTimer()
{
    if (!m_mockTimer.isActive()) {
        connect(&m_mockTimer, &QTimer::timeout,
                this, &MirrorManager::generateMockFrame,
                Qt::UniqueConnection);
        m_mockTimer.start(33); // ~30 FPS
    }
}

// QImage frame() const { return m_frame; }

