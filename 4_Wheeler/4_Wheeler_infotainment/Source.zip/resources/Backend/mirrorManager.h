#ifndef MIRRORMANAGER_H
#define MIRRORMANAGER_H

#pragma once
#include <QObject>
#include <QProcess>
#include <QImage>
// #include <qtimer.h>
#include <QTimer>
#include <QDebug>
// #include <QQuickImageProvider>
#ifdef Q_OS_ANDROID
#include <QAndroidJniObject>
#include <QtAndroid>
#include <jni.h>
#include <QAndroidJniEnvironment>
#endif

class MirrorManager : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool mirroring READ mirroring NOTIFY mirroringChanged)
    Q_PROPERTY(QImage frame READ frame NOTIFY frameUpdated)
public:

    explicit MirrorManager(QObject *parent = nullptr);
    static MirrorManager* instance() {
        static MirrorManager inst;
        return &inst;
    }
    void updateFrame(uint8_t *data, int w, int h);

    bool mirroring() const { return m_mirroring; }
    QImage frame() const { return m_frame; }
    // void generateFrame();
    // QImage currentFrame() const {}
    void startCapture();
    Q_INVOKABLE void startMirroring();
    Q_INVOKABLE void stopMirroring();
signals:
    void mirroringChanged();
    // void frameChanged();
    void frameUpdated();
    void frameReady(const QImage &image);

private slots:
    void generateFrame();
private:

    QProcess *scrcpyProcess;
    void generateMockFrame();
    void startMockTimer();
    bool m_mirroring = false;

    QTimer m_mockTimer;
    QImage m_frame;
};

#endif // MIRRORMANAGER_H
