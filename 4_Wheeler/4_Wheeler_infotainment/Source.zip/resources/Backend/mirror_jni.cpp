#ifdef Q_OS_ANDROID
#include <jni.h>
#include <QAndroidJniEnvironment>
#include <QAndroidJniObject>
extern "C" {

JNIEXPORT void JNICALL
Java_com_example_mirror_ScreenCaptureService_nativeOnFrame(
    JNIEnv *env,
    jobject /* this */,
    jobject buffer,
    jint width,
    jint height)
{
    //     jbyte *bytes = env->GetByteArrayElements(data, nullptr);

    //     QImage img(reinterpret_cast<uchar*>(bytes),
    //                width, height,
    //                QImage::Format_RGBA8888);
    //     qDebug() << "JNI frame received" << width << height;
    //     if (g_manager)
    //         emit g_manager->frameReady(img.copy());

    //     env->ReleaseByteArrayElements(data, bytes, 0);
}

} // extern "C"
#endif
#include <QImage>
#include "mirrorManager.h"

static MirrorManager *g_manager = nullptr;

// extern "C"{
//     JNIEXPORT void JNICALL
//     Java_org_qtproject_example_ScreenCaptureService_onFrame(
//         JNIEnv *env,
//         jobject,
//         jbyteArray data,
//         jint width,
//         jint height)
// {
//     jbyte *bytes = env->GetByteArrayElements(data, nullptr);

//     QImage img(reinterpret_cast<uchar*>(bytes),
//                width, height,
//                QImage::Format_RGBA8888);
//     qDebug() << "JNI frame received" << width << height;
//     if (g_manager)
//         emit g_manager->frameReady(img.copy());

//     env->ReleaseByteArrayElements(data, bytes, 0);
// }

void setMirrorManager(MirrorManager *mgr)
{
    g_manager = mgr;
}
