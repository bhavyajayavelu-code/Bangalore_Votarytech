#include "mirrorimageprovider.h"
#include "mirrorManager.h"
// MirrorImageProvider::MirrorImageProvider()
//     : QQuickImageProvider(QQuickImageProvider::Image),
//     m_manager(manager) {}

// MirrorImageProvider::MirrorImageProvider()
//     : QQuickImageProvider(QQuickImageProvider::Image)
// {
// }
MirrorImageProvider::MirrorImageProvider(MirrorManager *manager)
    : QQuickImageProvider(QQuickImageProvider::Image),
    m_manager(manager)
{
}
// MirrorImageProvider::MirrorImageProvider(){}
void MirrorImageProvider::setFrame(const QImage &img)
{
    m_frame = img;
}
// QImage MirrorManager::currentFrame() const {
//     return m_frame;
// }

QImage MirrorImageProvider::requestImage(const QString &id,
                                         QSize *size,
                                         const QSize &requestedSize)
{
    // qDebug() << "Image requested in request image";
    // Q_UNUSED(id)
    // Q_UNUSED(requestedSize)
    // if (!m_manager){
    //     qDebug() << "if condition !manager satisfied returning";
    //     return QImage();
    // }
    // qDebug() << " out iof condition !manager satisfied returning";
    // // MirrorManager::startCapture();
    // QImage frame = m_manager->frame();

    // if (size)
    //     *size = frame.size();

    // return frame;
    auto mgr = MirrorManager::instance();

    if (!mgr->mirroring())
        return QImage();

    return mgr->frame();
}
