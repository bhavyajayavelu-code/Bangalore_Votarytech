#ifndef MIRRORIMAGEPROVIDER_H
#define MIRRORIMAGEPROVIDER_H

#pragma once
#include "mirrorManager.h"
// #include <QQuickImageProvider>
#include <QImage>
#include <QQuickImageProvider>

// class MirrorImageProvider : public QQuickImageProvider/*, public QObject*/
// {
// public:
//     // MirrorImageProvider()
//     //     : QQuickImageProvider(QQuickImageProvider::Image)
//     // {}
//     explicit MirrorImageProvider(MirrorManager *manager);

//     QImage requestImage(const QString &id, QSize *size,
//                         const QSize &requestedSize) override;

//     void setImage(const QImage &img)
//     {
//         m_image = img;
//     }

// private:
//     QImage m_image;
//     MirrorManager *m_manager;
// };
class MirrorManager;
class MirrorImageProvider : public QQuickImageProvider
{
public:
    explicit MirrorImageProvider(MirrorManager *manager);
    // explicit MirrorImageProvider(MirrorManager *mgr)
    //     : QQuickImageProvider(QQuickImageProvider::Image),
    //     m_manager(mgr)
    // {}
    QImage requestImage(const QString &id,
                        QSize *size,
                        const QSize &requestedSize) /*override*/;
    void setFrame(const QImage &img);

private:
    MirrorManager *m_manager;
    QImage m_frame;

};

#endif // MIRRORIMAGEPROVIDER_H
