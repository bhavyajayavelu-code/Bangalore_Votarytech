package org.qtproject.example;

import android.app.Service;
import android.content.Intent;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.media.Image;
import android.media.ImageReader;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.hardware.display.VirtualDisplay;

import java.nio.ByteBuffer;

public class ScreenCaptureService extends Service {

    static {
        System.loadLibrary("mirror_jni");
    }

    private MediaProjection projection;
    private ImageReader imageReader;

    public native void onFrame(byte[] data, int width, int height);

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        MediaProjectionManager mgr =
            (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);

        projection = mgr.getMediaProjection(
            intent.getIntExtra("resultCode", -1),
            intent.getParcelableExtra("data"));

        DisplayMetrics metrics = new DisplayMetrics();
        ((WindowManager)getSystemService(WINDOW_SERVICE))
            .getDefaultDisplay().getMetrics(metrics);

        imageReader = ImageReader.newInstance(
            metrics.widthPixels,
            metrics.heightPixels,
            0x1, 2);

        projection.createVirtualDisplay(
            "QtMirror",
            metrics.widthPixels,
            metrics.heightPixels,
            metrics.densityDpi,
            0,
            imageReader.getSurface(),
            null, null);

        imageReader.setOnImageAvailableListener(reader -> {
            Image img = reader.acquireLatestImage();
            if (img == null) return;

            ByteBuffer buffer = img.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.remaining()];
            buffer.get(bytes);

            onFrame(bytes, img.getWidth(), img.getHeight());
            img.close();
        }, null);

        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
