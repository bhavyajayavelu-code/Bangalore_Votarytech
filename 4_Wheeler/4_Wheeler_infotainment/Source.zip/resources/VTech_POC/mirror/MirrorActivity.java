package com.VTech_POC.mirror;

import org.qtproject.qt5.android.bindings.QtActivity;
import java.nio.ByteBuffer;
import android.app.Activity;
import android.content.Intent;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.graphics.PixelFormat;



public class MirrorActivity extends QtActivity {

    static {
            System.loadLibrary("mirror_project_test_x86_64");
        }
    public native int nativePing(); //testing
    public native void testFromJava(); //testing

    public native void requestCaptureFromQt();
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private Handler handler;
    private native void nativeOnFrameAvailable(ByteBuffer buffer, int width, int height);
    private static final int SCREEN_CAPTURE_REQUEST = 1001;
    KeyEvent key = new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_BACK);

    private void injectTouch(float x, float y) {
        long downTime = SystemClock.uptimeMillis();
        long eventTime = downTime;

        MotionEvent event = MotionEvent.obtain(
            downTime,
            eventTime,
            MotionEvent.ACTION_DOWN,
            x, y,
            0
        );

        InputManager im = (InputManager)
            getSystemService(Context.INPUT_SERVICE);

        im.injectInputEvent(
            event,
            InputManager.INJECT_INPUT_EVENT_MODE_ASYNC
        );

        event.recycle();
    }
    private void injectBack() {
        long now = SystemClock.uptimeMillis();

        KeyEvent back = new KeyEvent(
            now, now,
            KeyEvent.ACTION_DOWN,
            KeyEvent.KEYCODE_BACK,
            0
        );

        InputManager im = (InputManager)
            getSystemService(Context.INPUT_SERVICE);

        im.injectInputEvent(back,
            InputManager.INJECT_INPUT_EVENT_MODE_ASYNC);
    }

    private final ImageReader.OnImageAvailableListener imageAvailableListener =
        reader -> {
            Image image = reader.acquireLatestImage();
            if (image == null) return;

            Log.d("MIRROR", "🔥 FRAME RECEIVED");


            // TODO: send buffer to native later
            ByteBuffer buf = image.getPlanes()[0].getBuffer();
            nativeOnFrameAvailable(buf, image.getWidth(), image.getHeight());

            image.close();
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("MIRROR", "onCreate function called");
        testFromJava();


    }
    public void startCaptureFromQt() {
        Log.d("MIRROR", "startCaptureFromQt called");
        requestScreenCapture();
    }


    public void requestScreenCapture() {
        Log.d("MIRROR", "requestScreenCapture fucntiion called");
        testFromJava();

        MediaProjectionManager mgr =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);

        Intent intent = mgr.createScreenCaptureIntent();
        startActivityForResult(intent, SCREEN_CAPTURE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("MIRROR", "nativePing=" + nativePing());

        Log.d("MIRROR", "onActivityResult function called");
        // Log.d("MIRROR", "Start mirroring clicked");
        Log.d("MIRROR", "requestCode=" + requestCode +
                        " resultCode=" + resultCode);
        Log.d("MIRROR", "Activity.RESULT_OK="+Activity.RESULT_OK);
        testFromJava();
        if (requestCode == SCREEN_CAPTURE_REQUEST || resultCode == Activity.RESULT_OK) {
            Log.d("MIRROR", "inside if SCREEN_CAPTURE_REQUEST ");
            // Intent service = new Intent(this, ScreenCaptureService.class);
            // service.putExtra("resultCode", resultCode);
            // service.putExtra("data", data);
            // startService(service);
            MediaProjectionManager projectionManager =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);

            mediaProjection = projectionManager.getMediaProjection(resultCode, data);
            // mediaProjection =
            //            projectionManager.getMediaProjection(resultCode, data);

                   startVirtualDisplay();
        }
    }
    private void startVirtualDisplay() {

    DisplayMetrics metrics = getResources().getDisplayMetrics();
    int width = metrics.widthPixels;
    int height = metrics.heightPixels;
    int dpi = metrics.densityDpi;

    imageReader = ImageReader.newInstance(
            width,
            height,
            PixelFormat.RGBA_8888,
            2
    );

    imageReader.setOnImageAvailableListener(
            imageAvailableListener,
            new Handler(Looper.getMainLooper())
    );

    virtualDisplay = mediaProjection.createVirtualDisplay(
            "MirrorDisplay",
            width,
            height,
            dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC, /*VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR*/
            imageReader.getSurface(),
            null,
            null
    );

    Log.d("MIRROR", "VirtualDisplay created");
    }

}
