package com.VTech_POC.mirror;

import android.graphics.PixelFormat;
import android.app.Service;
import android.content.Intent;
import android.graphics.ImageFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.IBinder;
import android.util.Log;

import java.nio.ByteBuffer;

public class ScreenCaptureService extends Service {

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {


        Log.d("MIRROR", "Start mirroring clicked on start command");
        int resultCode = intent.getIntExtra("resultCode", -1);
        Intent data = intent.getParcelableExtra("data");

        MediaProjectionManager mgr =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);

        projection = mgr.getMediaProjection(resultCode, data);

        startCapture();

        return START_NOT_STICKY;
    }

    private void startCapture() {
        // qDebug() << "Image requested";
        Log.d("MIRROR", "Start mirroring clicked on start command start capture");
        int width = 800;
        int height = 480;
        int dpi = getResources().getDisplayMetrics().densityDpi;

        imageReader = ImageReader.newInstance(
                width, height,
                // ImageFormat.RGBA_8888,
                PixelFormat.RGBA_8888,
                2
        );

        virtualDisplay = projection.createVirtualDisplay(
                "MirrorDisplay",
                width, height, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null, null
        );

        imageReader.setOnImageAvailableListener(reader -> {
            Image image = reader.acquireLatestImage();
            if (image != null) {
                Log.i("Mirror", "Frame captured: "
                        + image.getWidth() + "x" + image.getHeight());
                image.close();
            }
        }, null);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
