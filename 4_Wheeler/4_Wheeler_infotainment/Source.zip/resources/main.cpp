#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include "Backend/mirrorManager.h"
#include "Backend/mirrorimageprovider.h"
#include <QtAndroid>
// #include "Backend/mirrorimageprovider.h"
// #include "mirrorimageprovider.h"
int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    QAndroidJniObject activity = QtAndroid::androidActivity();
    activity.callMethod<void>("startCaptureFromQt");
    // MirrorManager mirrorManager;
    // MirrorManager *manager = new MirrorManager(&engine);
    // MirrorManager manager;                      //changes
    // auto mirrorManager = new MirrorManager(&engine);
    // auto *provider = new MirrorImageProvider(manager);
    // MirrorImageProvider *provider = new MirrorImageProvider;
    // engine.rootContext()->setContextProperty("<MirrorManager", &mirrorManager);
    engine.rootContext()->setContextProperty("MirrorManager", MirrorManager::instance());   //changes
    engine.addImageProvider("mirror",new MirrorImageProvider(MirrorManager::instance())); //changes
    // QObject::connect(&manager, &MirrorManager::frameReady,
    //                  provider, &MirrorImageProvider::setImage);
    // QObject::connect(&manager, &MirrorManager::frameReady,
    //                  [&](const QImage &img) {
    //                      provider->setFrame(img);
    //                  });

    // engine.addImageProvider("mirror", provider);


    // engine.rootContext()->setContextProperty(
    //     "MirrorManager", manager
    //     );

    engine.load(QUrl(QStringLiteral("qrc:/qml/main.qml")));
    // engine.load(QUrl(QStringLiteral("qrc:/qml/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;
    // if (engine.rootObjects().isEmpty())
    //     return -1;

    return app.exec();
}
