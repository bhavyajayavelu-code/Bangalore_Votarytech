#include <Arduino.h>
#include <WiFi.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Firebase_ESP_Client.h>

#include "addons/TokenHelper.h"
#include "addons/RTDBHelper.h"

/* ================= WiFi Credentials ================= */
#define WIFI_SSID        "iSprout-NRE"
#define WIFI_PASSWORD    "Isprout@n-202$"

/* ================= Firebase Credentials ================= */
#define API_KEY          "AIzaSyCR_FwvqqMGctW9i6MNn4ZUAGcuIjxPAqQ"
#define DATABASE_URL     "https://edge-data-filtering-default-rtdb.asia-southeast1.firebasedatabase.app/"
#define USER_EMAIL       "tejaswini.kopperla@votarytech.com"
#define USER_PASSWORD    "Votarytech@2025"

/* ================= Temperature Sensor ================= */
#define ONE_WIRE_BUS     15
#define TEMP_THRESHOLD   28.0

/* ================= Indicator Switch Pins ================= */
#define LEFT_INDICATOR_PIN   4
#define RIGHT_INDICATOR_PIN  5

/* ================= Objects ================= */
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);

FirebaseData fbdo;
FirebaseAuth auth;
FirebaseConfig config;

/* ================= Timing ================= */
unsigned long lastSend = 0;
const unsigned long interval = 5000;

/* ================= Alert Tracking ================= */
int highTempCount = 0;
bool wasAboveThreshold = false;

/* ================= Diagnostics ================= */
#define DTC_BATTERY_TEMP_SENSOR_FAULT "P0A1A"

bool dtc_active = false;
unsigned long fault_start_time = 0;
const unsigned long FAULT_CONFIRM_TIME = 3000; // ms

void diagnostics_check_temperature(float temperatureC)
{
    bool fault_condition =
        (temperatureC == DEVICE_DISCONNECTED_C ||
         temperatureC < -40.0 ||
         temperatureC > 125.0);

    if (fault_condition)
    {
        if (!dtc_active)
        {
            if (fault_start_time == 0)
                fault_start_time = millis();

            if (millis() - fault_start_time >= FAULT_CONFIRM_TIME)
            {
                dtc_active = true;
                Serial.println("🚨 DTC SET: P0A1A - Battery Temp Sensor Fault");

                Firebase.RTDB.setBool(&fbdo, "/dtc/P0A1A/status", true);
                Firebase.RTDB.setString(
                    &fbdo,
                    "/dtc/P0A1A/description",
                    "Battery Temperature Sensor Fault");
                Firebase.RTDB.setInt(
                    &fbdo,
                    "/dtc/P0A1A/timestamp",
                    millis());
            }
        }
    }
    else
    {
        fault_start_time = 0;

        if (dtc_active)
        {
            Serial.println("✅ DTC CLEARED: P0A1A");

            Firebase.RTDB.setBool(&fbdo, "/dtc/P0A1A/status", false);
            Firebase.RTDB.setString(
                &fbdo,
                "/dtc/P0A1A/description",
                "Battery Temperature Sensor OK");
        }

        dtc_active = false;
    }
}

void setup()
{
    Serial.begin(115200);

    pinMode(LEFT_INDICATOR_PIN, INPUT_PULLUP);
    pinMode(RIGHT_INDICATOR_PIN, INPUT_PULLUP);

    /* ---------- WiFi ---------- */
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    while (WiFi.status() != WL_CONNECTED)
        delay(500);

    /* ---------- Temperature Sensor ---------- */
    sensors.begin();

    /* ---------- Firebase ---------- */
    config.api_key = API_KEY;
    config.database_url = DATABASE_URL;
    auth.user.email = USER_EMAIL;
    auth.user.password = USER_PASSWORD;

    Firebase.begin(&config, &auth);
    Firebase.reconnectWiFi(true);
}

void loop()
{
    if (millis() - lastSend < interval)
        return;

    lastSend = millis();

    /* ================= TEMPERATURE ================= */
    sensors.requestTemperatures();
    float temperatureC = sensors.getTempCByIndex(0);

    /* Always send the temperature to Firebase, even if disconnected */
    Firebase.RTDB.setFloat(&fbdo, "/sensor/temperature", temperatureC);

    if (temperatureC == DEVICE_DISCONNECTED_C)
    {
        Serial.println("❌ DS18B20 not detected");

        Firebase.RTDB.setBool(
            &fbdo,
            "/diagnostics/battery_temp_sensor/status",
            true);
        Firebase.RTDB.setString(
            &fbdo,
            "/diagnostics/battery_temp_sensor/msg",
            "DS18B20 not detected");

        diagnostics_check_temperature(DEVICE_DISCONNECTED_C);
    }
    else
    {
        Serial.print("Temperature: ");
        Serial.print(temperatureC);
        Serial.println(" °C");

        diagnostics_check_temperature(temperatureC);

        /* Clear sensor diagnostic when OK */
        Firebase.RTDB.setBool(
            &fbdo,
            "/diagnostics/battery_temp_sensor/status",
            false);
        Firebase.RTDB.setString(
            &fbdo,
            "/diagnostics/battery_temp_sensor/msg",
            "Sensor OK");
    }

    /* ================= THRESHOLD ================= */
    bool isAboveThreshold = (temperatureC > TEMP_THRESHOLD);

    if (isAboveThreshold && !wasAboveThreshold)
        highTempCount++;

    wasAboveThreshold = isAboveThreshold;

    if (isAboveThreshold)
    {
        Firebase.RTDB.setBool(
            &fbdo,
            "/alerts/high_temp/status",
            true);
        Firebase.RTDB.setFloat(
            &fbdo,
            "/alerts/high_temp/value",
            temperatureC);

        Firebase.RTDB.setString(
            &fbdo,
            "/alerts/high_temp/msg",
            (highTempCount >= 3)
                ? "Service Required: Battery Temperature High"
                : "Temperature crossed 28C");
    }
    else
    {
        Firebase.RTDB.setBool(
            &fbdo,
            "/alerts/high_temp/status",
            false);
    }

    /* ================= INDICATORS ================= */
    bool leftOn   = (digitalRead(LEFT_INDICATOR_PIN) == LOW);
    bool rightOn  = (digitalRead(RIGHT_INDICATOR_PIN) == LOW);
    bool hazardOn = (leftOn && rightOn);

    int indicatorStatus = hazardOn ? 3 : (leftOn ? 1 : (rightOn ? 2 : 0));

    Firebase.RTDB.setInt(
        &fbdo,
        "/vehicle/indicator/status",
        indicatorStatus);
    Firebase.RTDB.setBool(
        &fbdo,
        "/vehicle/indicator/left_indicator",
        leftOn);
    Firebase.RTDB.setBool(
        &fbdo,
        "/vehicle/indicator/right_indicator",
        rightOn);
    Firebase.RTDB.setBool(
        &fbdo,
        "/vehicle/indicator/hazard",
        hazardOn);
}
