#include <opencv2/opencv.hpp>
#include <linux/fb.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <sys/ioctl.h>

static inline uint32_t make_argb(uint8_t r, uint8_t g, uint8_t b)
{
    return (0xFF << 24) | (r << 16) | (g << 8) | b;
}

int main(int argc, char *argv[])
{
    if (argc < 3) {
        printf("Usage: %s <video.avi> <haarcascade_eye.xml>\n", argv[0]);
        return -1;
    }

    const char *fb_path = getenv("FRAMEBUFFER");
    if (!fb_path) fb_path = "/dev/fb1";

    int fb = open(fb_path, O_RDWR);
    if (fb < 0) {
        perror("open framebuffer");
        return -1;
    }

    struct fb_var_screeninfo vinfo;
    struct fb_fix_screeninfo finfo;
    ioctl(fb, FBIOGET_VSCREENINFO, &vinfo);
    ioctl(fb, FBIOGET_FSCREENINFO, &finfo);

    int fb_w = vinfo.xres;
    int fb_h = vinfo.yres;
    int bpp  = vinfo.bits_per_pixel;

    printf("Framebuffer: %dx%d %dbpp\n", fb_w, fb_h, bpp);
    if (bpp != 32) {
        printf("Only 32bpp framebuffer supported\n");
        close(fb);
        return -1;
    }

    size_t fb_size = finfo.line_length * fb_h;
    uint8_t *fb_ptr = (uint8_t *)mmap(0, fb_size,
                                      PROT_READ | PROT_WRITE,
                                      MAP_SHARED, fb, 0);
    if (fb_ptr == MAP_FAILED) {
        perror("mmap");
        close(fb);
        return -1;
    }

    memset(fb_ptr, 0, fb_size);

    cv::VideoCapture cap(argv[1]);
    if (!cap.isOpened()) {
        printf("Failed to open video\n");
        munmap(fb_ptr, fb_size);
        close(fb);
        return -1;
    }

    cv::CascadeClassifier eye_cascade;
    if (!eye_cascade.load(argv[2])) {
        printf("Failed to load eye cascade\n");
        return -1;
    }

    int out_w = fb_w / 2;
    int out_h = fb_h / 2;

    cv::Mat frame, resized, gray;
    std::vector<cv::Rect> eyes;

    int frame_count = 0;
    int no_eye_streak = 0;
    bool drowsy = false;

    while (true) {
        if (!cap.read(frame)) {
            printf("End of video\n");
            break;
        }

        cv::resize(frame, resized, cv::Size(out_w, out_h));
        frame_count++;

        // Run Haar only every 5 frames (performance)
        if (frame_count % 5 == 0) {
            cv::cvtColor(resized, gray, cv::COLOR_BGR2GRAY);

            eyes.clear();
            eye_cascade.detectMultiScale(gray, eyes, 1.1, 3, 0, cv::Size(20,20));
            
            if (eyes.empty()) {
                no_eye_streak++;
            } else {
                no_eye_streak = 0;
                drowsy = false;   // Eyes seen → immediately clear warning
            }

            if (no_eye_streak >= 5) {
                drowsy = true;    // Eyes closed for a while
            }
        }

        if (drowsy) {
            cv::putText(resized, "DROWSINESS DETECTED",
                        cv::Point(10, 40),
                        cv::FONT_HERSHEY_SIMPLEX,
                        0.8, cv::Scalar(0,0,255), 2);
        }

        for (int y = 0; y < out_h; y++) {
            uint32_t *dst = (uint32_t *)(fb_ptr + y * finfo.line_length);
            uint8_t  *src = resized.ptr(y);

            for (int x = 0; x < out_w; x++) {
                uint8_t b = src[x*3 + 0];
                uint8_t g = src[x*3 + 1];
                uint8_t r = src[x*3 + 2];
                dst[x] = make_argb(r, g, b);
            }
        }
    }

    cap.release();
    munmap(fb_ptr, fb_size);
    close(fb);
    _exit(0);
}





