/*#ifndef AUDIO_H
#define AUDIO_H

void startAudio(const char* path);
void stopAudio();

#endif*/

#ifndef AUDIO_H
#define AUDIO_H

void play_alert(const char* wav_path);

#endif

