/*#include "audio.h"
#include <cstdlib>
#include <cstdio>

void startAudio(const char* path)
{
    char cmd[256];
    // hw:0,0 → usually headphone jack
    snprintf(cmd, sizeof(cmd), "aplay -D hw:0,0 %s &", path);
    system(cmd);
}

void stopAudio()
{
    system("killall aplay 2>/dev/null");
}*/

#include "audio.h"
#include <cstdio>     // ✅ REQUIRED for snprintf
#include <cstdlib>    // for system()

void play_alert(const char* wav_path)
{
    char cmd[256];
    snprintf(cmd, sizeof(cmd), "aplay %s &", wav_path);
    system(cmd);
}

