#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>

using namespace cv;
using namespace std;

enum OccupantType
{
    EMPTY,
    OBJECT,
    CHILD,
    ADULT
};

string toString(OccupantType t)
{
    switch(t)
    {
        case EMPTY:  return "EMPTY";
        case OBJECT: return "OBJECT";
        case CHILD:  return "CHILD";
        case ADULT:  return "ADULT";
        default:     return "UNKNOWN";
    }
}

// Original OMS classification based on foreground ratio
OccupantType classify(double ratio)
{
    if (ratio < 0.03) return EMPTY;
    if (ratio < 0.15) return OBJECT;
    if (ratio < 0.40) return CHILD;
    return ADULT;
}

int main()
{
    // -----------------------------
    // Step 1: Load empty seat reference
    // -----------------------------
    Mat emptyImg = imread("oms_input/empty/empty.jpg");
    if (emptyImg.empty())
    {
        cout << "Error: Empty reference image missing!" << endl;
        return -1;
    }
    cvtColor(emptyImg, emptyImg, COLOR_BGR2GRAY);
    GaussianBlur(emptyImg, emptyImg, Size(5,5), 0);

    // -----------------------------
    // Step 2: List of images
    // Child image repeated to simulate consecutive frames
    // -----------------------------
    vector<string> images = {
        "oms_input/adult/adult.jpg",
        "oms_input/child/child.jpg",
        "oms_input/child/child.jpg",
        "oms_input/child/child.jpg",
        "oms_input/object/object.jpg",
        "oms_input/empty/empty.jpg"
    };

    // -----------------------------
    // Step 3: CPD setup
    // -----------------------------
    int childCounter = 0;
    const int CPD_THRESHOLD = 3; // After 3 consecutive child frames, alert

    for (auto &path : images)
    {
        cout << "Processing: " << path << endl;

        // -----------------------------
        // Read and preprocess
        // -----------------------------
        Mat img = imread(path);
        if (img.empty())
        {
            cout << "Error: Image not found!" << endl;
            cout << "------------------------" << endl;
            continue;
        }

        resize(img, img, Size(emptyImg.cols, emptyImg.rows));
        Mat gray;
        cvtColor(img, gray, COLOR_BGR2GRAY);
        GaussianBlur(gray, gray, Size(5,5), 0);

        // -----------------------------
        // Background subtraction
        // -----------------------------
        Mat diff;
        absdiff(gray, emptyImg, diff);

        Mat fg;
        threshold(diff, fg, 25, 255, THRESH_BINARY);

        // -----------------------------
        // Foreground ratio & classification
        // -----------------------------
        double fgPixels = countNonZero(fg);
        double ratio = fgPixels / fg.total();

        OccupantType occ = classify(ratio);
        bool airbag = (occ == ADULT);

        // -----------------------------
        // CPD logic
        // -----------------------------
        if (occ == CHILD)
        {
            childCounter++;
            if (childCounter >= CPD_THRESHOLD)
            {
                cout << "ALERT: Child alone in the car! (CPD Triggered)" << endl;
            }
        }
        else
        {
            childCounter = 0; // reset if adult/object/empty
        }

        // -----------------------------
        // Output results
        // -----------------------------
        cout << "Foreground ratio: " << ratio << endl;
        cout << "Occupant type: " << toString(occ) << endl;
        cout << "Airbag " << (airbag ? "Activated" : "Deactivated") << endl;
        cout << "------------------------" << endl;

        // -----------------------------
        // Display (PC only)
        // -----------------------------
        imshow("Input Image", img);
        imshow("Foreground Mask", fg);
        cout << "Press any key to continue..." << endl;
        waitKey(0);
        destroyAllWindows();
    }

    return 0;
}
