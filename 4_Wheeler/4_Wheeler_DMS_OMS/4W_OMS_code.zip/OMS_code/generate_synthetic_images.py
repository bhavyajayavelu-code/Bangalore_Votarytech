import cv2
import numpy as np
import os

folders = ['adult', 'child', 'object', 'empty']
for f in folders:
    path = os.path.join('oms_input', f)
    os.makedirs(path, exist_ok=True)

img_size = (300, 300, 3)

# Adult
adult = np.full(img_size, 200, np.uint8)
cv2.rectangle(adult, (60, 50), (240, 250), (255,0,0), -1)
cv2.imwrite('oms_input/adult/adult.jpg', adult)

# Child
child = np.full(img_size, 200, np.uint8)
cv2.rectangle(child, (90, 100), (210, 220), (0,255,0), -1)
cv2.imwrite('oms_input/child/child.jpg', child)

# Object
obj = np.full(img_size, 200, np.uint8)
cv2.rectangle(obj, (110, 150), (190, 210), (0,0,255), -1)
cv2.imwrite('oms_input/object/object.jpg', obj)

# Empty
empty = np.full(img_size, 200, np.uint8)
cv2.imwrite('oms_input/empty/empty.jpg', empty)

print("Synthetic images created successfully!")
